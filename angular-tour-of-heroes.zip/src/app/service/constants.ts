export class Constants {    
  
    public static get API_BASE_URL(): string { return 'http://localhost:8081';}
   
    


}
